export interface Teacher {
  firstname: string;
  lastname: string;
  email: string;
}
