"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppDataSource = void 0;
var typeorm_1 = require("typeorm");
var User_1 = require("./entities/User");
var mysql2_1 = __importDefault(require("mysql2"));
var Student_1 = require("./entities/Student");
var Teacher_1 = require("./entities/Teacher");
exports.AppDataSource = new typeorm_1.DataSource({
    type: "mysql",
    driver: mysql2_1.default,
    host: "localhost",
    port: 3306,
    username: process.env['DB_USER'],
    password: process.env['DB_PASS'],
    database: "gestion_pfe",
    synchronize: true,
    logging: true,
    entities: [User_1.User, Student_1.Student, Teacher_1.Teacher],
    subscribers: [],
    migrations: [],
});
