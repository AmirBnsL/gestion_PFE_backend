"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.signJwt = void 0;
var jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
var signJwt = function (user) {
    if (!process.env['PRIVATE_KEY']) {
        throw new Error('PRIVATE_KEY is not set');
    }
    var secret = process.env['PRIVATE_KEY'];
    var options = {
        algorithm: 'HS256',
        expiresIn: '15d',
    };
    var payload = {
        sub: user.id.toString(),
        role: user.role,
        iat: Math.floor(Date.now() / 1000), // Use seconds since epoch
    };
    return jsonwebtoken_1.default.sign(payload, secret, options);
};
exports.signJwt = signJwt;
var verifyJwt = function (token) {
    if (!process.env['PUBLIC_KEY']) {
        throw new Error('PUBLIC_KEY is not set');
    }
    var secret = process.env['PUBLIC_KEY'];
    return jsonwebtoken_1.default.verify(token, secret);
};
