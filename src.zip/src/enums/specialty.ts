export enum Specialty {
  ISI = 'Informations Systems and Internet',
  SIW = 'Information Systems and Web',
  AIDS = 'Artificial intelligence and Data Sciences',
}

export default Specialty;